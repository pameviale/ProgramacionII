open List;
(*"Prueba de ML"*)
(*Está dificil esto profe {:c*)

(*----1----*)
datatype 'etiqueta arbolbin = Vacio | Nodo of 'etiqueta arbolbin * 'etiqueta * 'etiqueta arbolbin; 

(*a*)
fun PreOrden2(Vacio)=nil
|	PreOrden2(Nodo(izq,a,der))=[a]@PreOrden2(izq)@PreOrden2(der);

PreOrden2(Nodo(Nodo(Nodo(Vacio,8,Vacio),9,Vacio),10,Nodo(Vacio,11,Nodo(Vacio,13,Vacio))));

(*b*)
fun InOrden2(Vacio)=nil
|	InOrden2(Nodo(izq,a,der))=InOrden2(izq)@[a]@InOrden2(der);

InOrden2(Nodo(Nodo(Nodo(Vacio,8,Vacio),9,Vacio),10,Nodo(Vacio,11,Nodo(Vacio,13,Vacio))));

(*c*)
fun PostOrden2(Vacio)=nil
|	PostOrden2(Nodo(izq,a,der))=PostOrden2(izq)@PostOrden2(der)@[a];

PostOrden2(Nodo(Nodo(Nodo(Vacio,8,Vacio),9,Vacio),10,Nodo(Vacio,11,Nodo(Vacio,13,Vacio))));


(*----2----*)
type par= real * real;

(*a*)
fun	DistOC(x:real,y:real)= x*x + y*y;
fun Listdist(nil)= [] |
	Listdist(x:par list)= [DistOC(hd(x))]@Listdist(tl(x)); 

Listdist([(2.0,3.0),(5.0,3.0),(10.0,1.0)]);

(*b*)
fun Sumdist(nil)= 0.0 |
	Sumdist(x:par list)= DistOC(hd(x)) + Sumdist(tl(x));

Sumdist([(2.0,3.0),(5.0,3.0),(10.0,1.0)]);

(*c*)
fun Function(x:par)= if(DistOC(x)> 25.0) then true else false;
fun Puntosalejados(x:par list)= filter Function x;

Puntosalejados([(2.0,3.0),(5.0,3.0),(10.0,1.0)]);


(*----3----*)
(*a*)
fun	Listar_ord_creciente(x)= InOrden2(x);

Listar_ord_creciente(Nodo(Nodo(Nodo(Vacio,("Manuel",5),Vacio),("Julieta",6),Vacio),("Victor",8),Nodo(Vacio,("Hebe",9),Nodo(Vacio,("Gianni",10),Vacio))));

(*b*)
fun If10((x:string,y:int))= if(y=10) then true else false;
fun Buscar_sobresalientes(Nodo(l, (s:string,i:int), r))= filter If10 Listar_ord_creciente(Nodo(l, (s:string,i:int), r));

Buscar_sobresalientes(Nodo(Nodo(Nodo(Vacio,("Manuel",5),Vacio),("Julieta",6),Vacio),("Victor",8),Nodo(Vacio,("Hebe",9),Nodo(Vacio,("Gianni",10),Vacio))));