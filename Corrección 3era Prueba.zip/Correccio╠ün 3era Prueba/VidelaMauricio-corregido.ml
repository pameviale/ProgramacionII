(*Videla, Mauricio*)
(*E-Mail: mauriciando1@hotmail.com*)
(*5° año división Informática*)
(*Evaluación 31-10-2016*)
open List;
(*1*)
datatype 'a bt = V | N of 'a bt * 'a * 'a bt;
(*1a*)
fun pre(V) = [] |
	pre(N(l,d,r)) = [d]@pre(l)@pre(r);
(*1b*)
fun ino(V) = [] |
	ino(N(l,d,r)) = ino(l)@[d]@ino(r);
(*1c*)
fun pos(V) = [] |
	pos(N(l,d,r)) = pos(l)@pos(r)@[d];
(*2*)
type par = real * real;
val pts = [(2.0,4.0),(1.0,7.0),(0.0,0.0),(6.0,7.0)];
fun p(x:real,0.0) = 1.0 |
	p(x,1.0) = x |
	p(x,y) = x*p(x,y-1.0);
fun doc(x,y) = p(x,2.0)+p(y,2.0);
(*2a*)
val ldis = map doc;
(*2b*)
fun sm(x:real,y) = x+y;
fun sdis(x) = foldr sm 0.0 (ldis x);
(*2c*)
fun c(x,y) = doc(x,y)>5.0;
fun palj([]) = [] |
	palj(L:par list) = filter c L;
(*3*)
val dic = N(N(V,("neron",7),N(V,("justiniano",10),V)),("cesar",4),N(V,("adriano",10),V));
(*3a*)
fun ocre(t:(string * int) bt) = ino(t);
(*3b*)
fun k(s,i:int) = i=10;
fun bsob(t:(string * int) bt) = filter k (ino(t));
(*Ejercicio recuperatorio*)
(*ERa*)
fun ingr((s:string,n:int),V) = N(V,(s,n),V) |
	ingr((s,n),N(l,(x,y),r)) = if s=x then N(l,(x,y),r) else 
								if s>x then N(ingr((s,n),l),(x,y),r) else 
									N(l,(x,y),ingr((s,n),r));
(*ERb*)
fun modn((s:string,n:int),V) = V |
	modn((s,n),N(l,(x,y),r)) = if s=x then N(l,(s,n),r) else 
								if s>x then N(modn((s,n),l),(x,y),r) else 
									N(l,(x,y),modn((s,n),r));
(*ERc*)
fun t(x) = if x>=6 then "Aprobado" else "No aprobado";
fun apro(s:string,V) = "No se conoce la nota del alumno" |
	apro(s,N(l,(x,y),r)) = if s=x then t(y) else 
							if s>x then apro(s,l) else 
								apro(s,r);
(*ERd*)
fun nomb(n:int,V) = [] |
	nomb(n,N(l,(x,y),r)) = if n=y then [x]@nomb(n,l)@nomb(n,r) else 
							nomb(n,l)@nomb(n,r);