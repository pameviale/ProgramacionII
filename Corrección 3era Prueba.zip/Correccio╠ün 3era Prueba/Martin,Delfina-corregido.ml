
Corrección:

- La defunción de listar_en_orden_creciente debía usar alguna de las funciones definidas en el apartado 1

- La función filter es currificada, error al usarla


open List;
-------------------------------------------------------
1.a.

fun preorden(Vacio)= []
| preorden(Nodo(izq,a,der)) = [a]@preorden(izq)@preorden(der);

1.b.

fun inorden(Vacio)= []
| inorden(Nodo(izq,a,der)) = inorden(izq)@[a]@inorden(der);

1.c.

fun postorden(Vacio)= []
| postorden(Nodo(izq,a,der)) = postorden(izq)@postorden(der)@[a];
-------------------------------------------------------
test: val arbol = Nodo(Nodo(Vacio,3,Vacio),5,Nodo(Vacio,7,Vacio));
val arbol = Nodo(Nodo(Vacio, 3, Vacio), 5, Nodo(Vacio, 7, Vacio)) :
  int arbolbin
-------------------------------------------------------
2.a.

fun aux((x,y):par)= x*x + y*y; 

fun listdist(L:par list) =  map aux L;

2.b.
(*aux definida en el item anterior*)

fun suma((x,y):par) = x+y;

fun sumdist(L:par list) = foldr suma 0.0 (map aux L);

- sumdist(ejemplo);
> val it = 17.0 : real

2.c.

fun lejos((x,y):par) = ((x*x+y*y)>5.0);

fun puntosalejados(L:par list) = filter(lejos,L);
-----------------------------------------------------------
test: val ejemplo:par list = [(1.0,1.0),(1.0,2.0),(1.0,3.0)];
val ejemplo = [(1.0, 1.0), (1.0, 2.0), (1.0, 3.0)] : (real * real) list
-----------------------------------------------------------
3.a.

fun listar_en_orden_creciente (Vacio) = []
| listar_en_orden_creciente (Nodo(izq,(x:string,y:int),der)) = listar_en_orden_creciente (izq)@[(x,y)]@listar_en_orden_creciente(der);

3.b.

fun sobresaliente (x:string,y:int) = (y=10);

fun buscar_sobresaliente (Vacio) = []
| buscar_sobresaliente (Nodo(izq,(x:string,y:int),der)) =  filter(sobresaliente,filter(listar_en_orden_creciente,Nodo(izq,(x:string,y:int),der)));



