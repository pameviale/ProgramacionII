(*
Corrección: 

- El examen está muy bien.

- Hay un error en la función puntosalejados, que la idea era que
devolviera la lista de puntos alejados, no la lista de sus distancias.

- Si bien las funciones listar_en_orden_creciente y buscar_sobresaliente están bien, otra forma de definirlas de manera más sencilla es:

fun listar_en_orden_creciente (ar: string * int arbolbin) = inorden(ar);

fun buscar_sobresaliente (ar: string * int arbolbin) = filter diez (listar_en_orden_creciente(ar));

ya que la recursión sobre el árbol la hace la función inorden.

===============================================================================
)*

datatype 'etiqueta arbolbin = vacio | nodo of 'etiqueta arbolbin * 'etiqueta * 'etiqueta arbolbin ;

open List;

fun preorden (vacio) = nil
| preorden (nodo(izq, x, der)) = [x]@(preorden(izq))@(preorden(der));

fun inorden (vacio) = nil
| inorden (nodo(izq, x, der)) = (inorden(izq))@[x]@(inorden(der));

fun postorden (vacio) = nil
| postorden (nodo(izq, x, der)) = (postorden(izq))@(postorden(der))@[x];

fun distancia (x: (real * real)) = #1(x) * #1(x) + #2(x) * #2(x);

fun listdist (l: (real * real) list) = map distancia l ;

fun suma (a: real, b: real) = a + b;

fun sumdist (l: (real * real) list) = foldl suma 0.0 (listdist (l));

fun mayoracinco (x) = x>5.0 ;

fun puntosalejados (l: (real * real) list) = filter mayoracinco (listdist (l));

fun listar_en_orden_creciente (vacio) = nil
| listar_en_orden_creciente (nodo(izq, (nombre: string, nota: int), der)) = inorden(nodo(izq, (nombre, nota), der));

fun diez (x: (string * int)) = #2(x) = 10;

fun buscar_sobresaliente (vacio) = nil
| buscar_sobresaliente (nodo(izq, (nombre: string, nota: int), der)) = filter diez (listar_en_orden_creciente(nodo(izq, (nombre, nota), der)));