
Corrección:

_ Muy bien

- Una posible implementación del último ejercicio 3b):

fun sobresaliente (x,y) = y=10;
fun Buscar_sobresaliente ar = filter sobresaliente (listar_en_orden_creciente ar);



(*1*)
datatype 'etiqueta arbolbin =
Vacio |
Nodo of 'etiqueta arbolbin * 'etiqueta * 'etiqueta arbolbin;

(*1.a*)
fun preOrden(Vacio)=nil
|preOrden(Nodo(izq,a,der))=[a]@preOrden(izq)@preOrden(der);

(*1.b*)
fun inOrden(Vacio)=nil
|inOrden(Nodo(izq,a,der))=inOrden(izq)@[a]@inOrden(der);

(*1.c*)
fun postOrden(Vacio)=nil
|postOrden(Nodo(izq,a,der))=postOrden(izq)@postOrden(der)@[a];

(*2*)
open Math;
open List;
type par = real * real;
fun dist(x:real,y)=sqrt (x*x+y*y);

(*2.a*)
val listdist=map dist;

(*2.b*)
fun suma(nil)=0.0
|suma(x:real list)=hd(x)+(suma(tl(x)));
val sumdist = suma o listdist;

(*2.c*)
fun P(x,y)=if((dist(x,y))>5.0) then true else false;
fun puntosalejados h = filter P h;

(*3.a*)
fun listar_en_orden_creciente(ar:(string * int) arbolbin)=inOrden(ar);

(*3.b*)
fun P(x:string,y:int)=y;
val Pmap=map P;
val j=listar_en_orden_creciente;
fun comb(x)=Pmap (j x);
fun exce(x)=if(x=10) then true else false;
val comb2=map exce comb;
fun buscar_sobresaliente ar = filter comb ar;
