(*
Corrección:

- El examen está muy bien

- Solo quería comentarte que hay funciones que podían implementarse de otra forma:

fun puntosalejados(L: par list) = filter may5 L;
fun listar_en_orden_creciente (ar: string * int arbolbin) = inOrden (ar);
fun buscar_sobresalientes(ar: string * int arbolbin) = filter es10 (listar_en_orden_creciente (ar));

=================================================================
*)

open List;

datatype 'etiqueta arbolbin = Vacio
|Nodo of 'etiqueta arbolbin * 'etiqueta * 'etiqueta arbolbin;

type par = real*real;

(*1.a*)

fun preOrden (Vacio) = nil
|preOrden (Nodo(izq,a,der)) = [a]@preOrden(izq)@preOrden(der);

(*1.b*)

fun inOrden (Vacio) = nil
|inOrden (Nodo(izq,a,der)) = inOrden(izq)@[a]@inOrden(der);

(*1.c*)

fun postOrden (Vacio) = nil
|postOrden (Nodo(izq,a,der)) = postOrden(izq)@postOrden(der)@[a];

(*2.a*)

fun dist (x:par) = #1x * #1x + #2x * #2x;

fun listdist (L:par list) = map dist L;

(*2.b*)

fun sum (x,y:real) = x+y;

fun sumdist (L:par list) = foldl sum 0.0 (listdist L);

(*2.c*)

fun may5 (x:par) = dist(#1x,#2x)>5.0;

fun puntosalejados([]) = nil
|puntosalejados (L:par list) = filter may5 L;

(*3.a*)

fun listar_en_orden_creciente (Vacio) = []
|listar_en_orden_creciente (Nodo(izq,a,der)) = inOrden (Nodo (izq,a,der));

(*3.b*)

fun es10 (x:(string*int)) = #2x=10;

fun buscar_sobresalientes(Vacio) = nil
|buscar_sobresalientes (Nodo(izq,a,der)) = filter es10 (listar_en_orden_creciente (Nodo(izq,a,der)));
