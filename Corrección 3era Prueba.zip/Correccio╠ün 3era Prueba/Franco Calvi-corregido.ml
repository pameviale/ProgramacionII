1)a) fun preorden(Vacio)=nil 
     |   preorden(Nodo(izq,a,der))= [a]@peorden(izq)@preorden(der);
1)b) fun inorden(Vacio)=nil
     |   inorden(Nodo(izq,a,der))=inorden(izq)@[a]@inorden(der);
1)c) fun postorden(Vacio)=nil
     |   postorden(Nodo(izq,a,der)=postorden(izq)@postorden(der)@[a];
3)a) fun listar_en_orden_creciente(arbol)=inorden(arbol);
3)b) fun capos(x,y)= y=10;
     fun buscar_sobresalientes(arbol)= filter capos listar_en_orden_creciente(arbol);
2)a) fun dist_origen_coordenadas(x:real,y:real)=x*x+y*y;
     fun list_dist(x:(real * real) list)=map dist_origen_coordenadas x;
2)b) fun suma(x:real,y)=x+y;
     fun sumdist x = foldr suma 0.0 (list_dist x);
2)c) fun dist(x:real,y) = y=5;
     fun puntosalejados(x) = filter dist (map dist_origen_coordenadas x);

