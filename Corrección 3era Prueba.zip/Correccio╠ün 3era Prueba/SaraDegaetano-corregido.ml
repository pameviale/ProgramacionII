(*
Corrección:

- El tipo type estudiante= real * int debería ser type estudiante= string * int

- Aparece el tipo preestudiante arbolbin en vez de estudiante arbolbin en:
	fun buscar_sobresalientes(arbol:preestudiante arbolbin) = …..


=============================================================================

*)

open List;
datatype 'etiqueta arbolbin = Vacio | Nodo of 'etiqueta arbolbin * 'etiqueta * 'etiqueta arbolbin;
(*1a*)fun preOrden(Vacio)= nil | preOrden(Nodo(izq,r,der))= [r]@preOrden(izq)@preOrden(der);
(*1b*)fun inOrden(Vacio)= nil | inOrden(Nodo(izq,r,der))= inOrden(izq)@[r]@inOrden(der);
(*1c*)fun postOrden(Vacio)= nil | postOrden(Nodo(izq,r,der))= postOrden(izq)@postOrden(der)@[r];

type par = real * real;
fun dist_origen_coordenadas((x,y):par)=(x*x)+(y*y);
(*2a*) fun listdist(l:par list)= map dist_origen_coordenadas l;
(*2b*) fun suma((x,y):par)=x+y;
	fun sumdist(l:par list)= foldl suma 0.0 (listdist(l));
(*2c*) fun mayorque((x,y):par)= if dist_origen_coordenadas(x,y)>5.0 then true else false;
	fun puntosalejados(l:par list)= filter mayorque l;
	
type estudiante= real * int;
(*3a*) fun listar_en_orden_creciente(Vacio)= nil | listar_en_orden_creciente(arbol:estudiante arbolbin)=inOrden(arbol);
(*3b*) fun excelente((x,y):estudiante)=if y=10 then true else false;
	fun buscar_sobresalientes(arbol:preestudiante arbolbin)= filter excelente (listar_en_orden_creciente(arbol));