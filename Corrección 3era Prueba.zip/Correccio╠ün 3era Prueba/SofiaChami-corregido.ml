(*
Corrección: 

El examen está muy bien.

El único error se encuentra en la función puntosalejados, que la idea era que
devolviera la lista de puntos alejados, no la lista de sus distancias.


============================================================================
*)

(*1*)
(*a*)
fun preorden(vacio) = nil
| preorden (nodo(izq,a,der))= 
[a] @ preorden(izq) @ preorden(der);

(*b*)
fun inorden(vacio) = nil
| inorden (nodo(izq,a,der))= 
 inorden(izq) @ [a] @ inorden(der);

(*c*)
fun postorden(vacio) = nil
| postorden (nodo(izq,a,der))= 
 postorden(izq) @ postorden(der)@ [a];

(*2*)
(*a*)

fun listdist (l:par list)= map dist l;

fun cuadrado (x:real) = x*x;

fun suma(x:real,y:real)= x+y;

fun dist((x:real,y:real))= suma(cuadrado(x), cuadrado(y));

(*b*) 

fun sumdist l = foldr suma 0.0 (listdist(l));
fun suma(x:real,y) = x+y; 

(*c*)

fun mayor(x:real)= if x>5.0 then true else false;

fun puntosalejados (l:par list) = filter mayor (listdist(l));

(*3*)
(*a*)
fun listar_en_orden_creciente (l:(string * int) arbolbin)  = inorden l;
(*b*)
fun sobresaliente(x,y)= if y=10 then true else false;

fun buscar_sobresalientes (x:(string*int) arbolbin) = filter sobresaliente(listar_en_orden_creciente(x));









