Corrección:

- Error de tipo en sumlist, debe devolver real
- En la definición de puntosalejados l es una lista de elementos de tipo par, o sea que alejados debería tomar un par, no un real
- listar_en_orden_creciente no considera el caso del árbol vacio
- buscar_sobresalientes no considera el caso del árbol vacio
================================================================
-open List;
-datatype 'etiqueta arbolbin =
Vacio|
Nodo of 'etiqueta arbolbin * 'etiqueta * 'etiqueta arbolbin;
-type par = real * real;
-fun dist_origen_coordenadas (x:real,y:real) = x*x+y*y 

(*Ejercicio 1*)
-fun pre0rden (Vacio) = nil 
|pre0rden (Nodo(izq,a,der) = [a]@pre0rden(izq)@pre0rden(der);

-fun in0rden (Vacio) = nil
|in0rden (Nodo(izq,a,der) = in0rden(izq)@[a]@in0rden(der);

-fun post0rden (Vacio) = nil
|post0rden (Nodo(izq,a,der) = post0rden(izq)@post0rden(der)@[a];

(*Ejercicio 2*)
-fun listdist (l:par list) = map dist_origen_coordenadas l;

-sumlist (nil)= 0
|sumlist (l:par list) = dist_origen_coordenadas(hd(l))+sumlist(tl(l));

-fun alejados (x:real) = (x>25.0);
-fun puntosalejados (l:par list) = filter alejados l;

(*Ejercicio 3*)
-fun listar_en_orden_creciente (Nodo(izq,(x:string,y:int),der)) = in0rden (Nodo(izq,(x,y),der);

-fun sobresalientes (x,y) = (y=10);
-fun buscar_sobresalientes (Nodo(izq,(x:string,y:int),der)) = filter sobresalientes listar_en_orden_creciente(Nodo(izq,(x,y),der)); 
