(*
Corrección:

- El examen está muy bien.

===================================================================================
*)

datatype 'etiqueta arbolbin = 
	Vacio |
	Nodo of 'etiqueta arbolbin * 'etiqueta * 'etiqueta arbolbin;

open List;

val a= Nodo(Nodo(Vacio,("angel",8),Vacio),("facundo",10),Nodo(Vacio,("rassol",4),Vacio));
val b= [(1.0,2.0),(10.0,3.0),(3.0,3.0)];

(*1 a*)
fun preOrden Vacio = nil
| preOrden (Nodo(izq,a,der)) = [a] @ preOrden(izq) @ preOrden(der);

(*1 b*)
fun inOrden Vacio = nil
| inOrden (Nodo(izq,a,der)) = inOrden(izq) @ [a] @ inOrden (der);

(*1 c*)
fun postOrden Vacio = nil
| postOrden (Nodo(izq,a,der)) = postOrden(izq) @ postOrden (der) @ [a];

(*2 a*)
type par = real * real;

fun dist_origen_de_coordenadas(x:real,y) = (x*x) + (y*y);

fun listdist L = map dist_origen_de_coordenadas L;

(*2 b*)
fun sum(q:real,y) = q+y;
fun sumdist L = foldl sum 0.0 (listdist(L)); 

(*2 c*)
fun estrictmayor (z:real,y) = dist_origen_de_coordenadas(z,y) > 5.0;

fun puntosalejados L = filter estrictmayor L;
 
(*3 a listar_en_orden_creciente = leoc*)
fun leoc ar = inOrden(ar);

(*3 b*) 
fun sobresalientes (x:string,n:int) =  n=10;

fun buscar_sobresalientes ar = filter sobresalientes (leoc(ar)) ;

