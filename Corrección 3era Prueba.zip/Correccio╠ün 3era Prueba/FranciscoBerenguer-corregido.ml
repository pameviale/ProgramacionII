(* Corrección:

- Excelente


=================================== *)


open List;

datatype 'etiqueta arbolbin=
	Vacio |
	Nodo of 'etiqueta arbolbin * 'etiqueta * 'etiqueta arbolbin;

(*1a*)
fun preOrden (Vacio) = nil
|     preOrden (Nodo(izq,a,der))=[a]@preOrden(izq)@preOrden(der);
(*1b*)
fun inOrden (Vacio) = nil
|     inOrden (Nodo(izq,a,der))=inOrden(izq)@[a]@inOrden(der);
(*1c*)
fun postOrden (Vacio) = nil
|     postOrden (Nodo(izq,a,der))=postOrden(izq)@postOrden(der)@[a];
(*2*)
type par=real * real;
val L=[(1.0,2.0),(1.0,1.0),(2.0,2.0),(3.0,4.0)];
(*2a*)
fun raiz (x:par)=((#1(x))*(#1(x))+(#2(x))*(#2(x))); 
fun listdist (L:par list)=map raiz L;  
(*2b*)
fun suma(x:real , y:real) = x + y;
fun sumdist (L:par list)=foldr suma 0.0 (map raiz L); 
(*2c*)
fun funcionfiltro(x:par)=(raiz(x)>(5.0));
fun puntosalejados(L:par list)=filter funcionfiltro L;
(*3*)
datatype 'etiqueta arbolbin=
	Vacio |
	Nodo of 'etiqueta arbolbin * 'etiqueta * 'etiqueta arbolbin;
val xd=Nodo(Nodo(Vacio,("armando",10),Vacio),("barton",5),Nodo(Vacio,("cabeza",6),Vacio));
(*3a*)
fun listarenordencreciente (jaja)=inOrden(jaja);
(*3b*)
fun notadiez (x:(string * int))=((#2(x))=10);
fun buscarsobresalientes (jeje:(string * int) arbolbin)=filter notadiez (listarenordencreciente(jeje)); 
