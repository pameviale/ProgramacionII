
Corrección:

- Faltan punto y coma al final de la función s

- Definición doble de par y una con el olvido de ;

- Olvido de | en las 3 funciones del ejercicio 1

- Error función rz: 2# en vez de #2 



1) --------------------------------------------------------------
  datatype 'x arbolbin=
	vacio|
	nodo of 'x arbolbin * 'x * 'x arbolbin;


a*
  fun preOrden(vacio)=nil
preOrden(nodo(izq,x,der))=[x]@preOrden(izq)@preOrden(der);

b*
  fun inOrden(vacio)=nil
inOrden(nodo(izq,x,der))=inOrden(izq)@[x]@inOrden(der);

c*
  fun postOrden(vacio)=nil
postOrden(nodo(izq,x,der))=postOrden(izq)@postOrden(der)@[x];

2)----------------------------------------------------------------
  type par= real * real;
type par= real * real

a*
  fun rz(x:par)=((#1(x))*(#1(x))+(#2(x))*(2#(x)));
fun listdist(y:par list)=(map rz y);

b*

c*
  fun filtro(x:par)=(rz(x)>(5.0));
fun puntosalejados(y:par list)=filter filtro y;
  
3) ---------------------------------------------------------------------

a*
  fun listar_en_orden_creciente(x)=inOrden(x);

b*
  fun s(x,y)= x = 10
fun buscar_sobresaliente(y)= filter s(listar_en_orden_creciente y);
-------------------------------------------------------------------------
