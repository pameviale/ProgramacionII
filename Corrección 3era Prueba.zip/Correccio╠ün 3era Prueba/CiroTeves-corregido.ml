
(*
Correcci�n:

  - Hay problemas de tipo en algunas funciones. Como no especific�s ml toma el tipo por defecto, o sea, int en lugar de real. Por ejemplo: 

       - fun suma(x:real,y:real) = x+y;	 fun cuad(x:real) = x*x;         fun dist_origen_coordenadas(x:real,y:real) = Real.Math.sqrt(suma(cuad(x),cuad(y)));

       - En la funci�n sumlist en el caso de la lista vac�a debe devolver 0.0:real y no 0:int 
         fun sumlist(L:par list) = foldr suma 0.0 (map dist_origen_coordenadas L);


   - Est�n mal las funciones listar_en_orden_creciente y buscar_sobresalientes. Qu� es el par�metro r? 
     Soluciones posibles ser�an las siguientes:
	
	fun listar_en_orden_creciente(vacio)=nil
	|listar_en_orden_creciente(Nodo(izq,(x:string,y:int),der))=inOrden(Nodo(izq,(x,y),der));
	
	fun buscadiez(x:string,y:int)=if (y=10) then true else false;
	fun buscar_sobresalientes(vacio)=[] 
	|buscar_sobresalientes(Nodo(izq,(x:string,y:int),der))=filter buscadiez (listar_en_orden_creciente(Nodo(izq,(x,y),der)));

============================================================
*)

(*31-10-2016*)(*Evaluaci�n ML - Ciro Teves 5to Inform�tica*)open List;(*1*)(*Definici�n �rbol binario*)datatype 'etiqueta arbolbin = Vacio |Nodo of 'etiqueta arbolbin * 'etiqueta * 'etiqueta arbolbin;(*1a*)fun preOrden(Nodo(l,a,r)) = [a]@preOrden(l)@preOrden(r);(*1b*) fun inOrden(Nodo(l,a,r)) = inOrden(l)@[a]@inOrden(r);(*1c*)fun postOrden(Nodo(l,a,r)) = postOrden(l)@postOrden(r)@[a];(*2*)(*Definici�n de par*)type par = real * real;(*2a*)fun suma(x,y) = x+y;fun cuad(x) = x*x;fun dist_origen_coordenadas(x,y) = Real.Math.sqrt(suma(cuad(x),cuad(y)));fun listdist(L:par list) = map dist_origen_coordenadas L;(*2b*)fun sumlist(L:par list) = foldr suma 0 (map dist_origen_coordenadas L);(*2c*)fun may(x) = if x>5.0 then true else false;fun puntosalejados(L:par list) = filter may L;(*3a*)fun listar_en_orden_creciente(a) = [] |listar_en_orden_creciente(Nodo(l,(alumno:string,nota:int))) = inOrden(l,(alumno,nota),r);(*3b*)fun condicion(alumno:string,nota:int) = nota>9;fun buscar(L) = filter condicion L;fun buscar_sobresalientes(a) = [] |buscar_sobresalientes(Nodo(l,(alumno,nota),r)) = buscar(listar_en_orden_creciente(Nodo(l,(alumno,nota),r)));