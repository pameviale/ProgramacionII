Corrección:

- Excelente


open List;
datatype 'z arbolbin =
	Vacio |
	Nodo of 'z arbolbin * 'z * 'z arbolbin;

fun preOrden(Vacio)=nil
|preOrden (Nodo (izq,z,der))=[z]@preOrden(izq)@preOrden(der);

fun inOrden(Vacio)=nil
|inOrden (Nodo (izq,z,der))=inOrden(izq)@[z]@inOrden(der);

fun postOrden(Vacio)=nil
|postOrden (Nodo (izq,z,der))=postOrden(izq)@postOrden(der)@[z];

(* Ejercicio nùmero 2 *)
type par = real * real;
fun dist_origen_coordenadas(x:real,y:real)= x*x+y*y;

fun listdist (a:(real*real)list)=map dist_origen_coordenadas a;

fun sumaaux(x:real,y)=x+y;
fun sumdist x = foldr sumaaux 0.0 (listdist x);


(* Ejercicio nùmero 3 *)
fun listar_en_orden_creciente a=inOrden(a);

fun ssaliente(a,b)= b=10;
fun buscar_sobresaleintes(a)=filter ssaliente(listar_en_orden_creciente a);
