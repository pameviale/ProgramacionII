(*
Corrección: 

Mal listdist debe devolver una lista de distancias

Mal listdist devuelve un valor, no una lista de distancias - sumlist debe recibir una lista : fun sumdist L= sumlist (listdist L);

Error parámetro l distinto de L: fun puntosalejados l= filter mayor5 L;

Error: dice inOrder en vez de inOrden en la definición de listcrec

=================================================================
*)

EJ 1
fun preOrden(vacio)=nil
|preOrden(Nodo(izq,a,der))=[a]@preOrden(izq)@preOrden(der);

fun inOrden(vacio)=nil
|inOrden(Nodo(izq,a,der))=inOrden(izq)@[a]@inOrden(der);

fun postOrden(vacio)=nil
|postOrden(Nodo(izq,a,der))=postOrden(izq)@postOrden(der)@[a];


EJ 2
type par = real*real;
a)
fun dist_origen_coordenadas(x:real, y:real)=x*x+y*y;
fun listdist L=foldr dist_origen_coordenadas L;
b)
fun sumlist nil=0.0
|sumlist (x::xs)= x+ sumlist xs;
fun sumdist L= sumlist (listdis L);
c)
open list;
fun mayor5 (x,y)=dist_origen_coordenadas(x,y)>5.0;
fun puntosalejados l= filter mayor5 L;


EJ 3
a)
fun listcrec arbolbin = inOrder arbolbin;
b)
fun ss (x,y)= y=10;
fun buscar_ss arbolbin = filter ss (listcrec arbolbin);

