open List;

datatype 'etiqueta arbolbin =
	Vacio |
	Nodo of 'etiqueta arbolbin * 'etiqueta * 'etiqueta arbolbin;

val a = Nodo(Nodo(Nodo(Vacio,("G",10),Vacio),("F",10),Nodo(Vacio,("C",7),Vacio)),("B",8),Nodo(Vacio,("A",6),Vacio));


(*1 A*)

fun preOrden Vacio = []
| preOrden (Nodo(izq,n,der)) = [n]@preOrden(izq)@preOrden(der);

(*1 B*)

fun inOrden Vacio = []
| inOrden(Nodo(izq,n,der)) = inOrden(izq)@[n]@inOrden(der);

(*1 C*)

fun postOrden Vacio = []
| postOrden(Nodo(izq,n,der)) = postOrden(izq)@postOrden(der)@[n];

(*2 A*)

type par = real * real;

fun dist (x:real,y) = (x*x)+(y*y);

fun listdist(L) = map dist L; 

val p =[(2.0,3.0):par,(4.0,2.0),(5.0,3.0),(1.0,1.0)];

(*2 B*)

fun suma(x:real,y) = x+y;

fun sumdist L = foldl suma 0.0 (listdist(L))

(*2 C*)

fun may (x:real,y) = dist(x,y) > 5.0;

fun puntosalejados L = filter may L;

(*3 A*)

fun listar_en_orden_creciente l = inOrden l;


(*3 B*)

fun aprob (x:string,y:int) = y = 10;

fun buscar_sobresaliente ar = filter aprob (listar_en_orden_creciente ar);
