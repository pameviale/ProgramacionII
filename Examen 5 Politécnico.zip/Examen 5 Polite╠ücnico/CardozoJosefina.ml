datatype 'etiqueta arbolbin =
			Vacio | 
			Nodo of 'etiqueta arbolbin * 'etiqueta * 'etiqueta arbolbin;

(*ejercicio 1*)
fun pre0rden (Vacio) = nil
|	pre0rden (Nodo (izq,a,der))= [a]@pre0rden(izq)@pre0rden(der);

fun in0rden (Vacio) = nil
|	in0rden (Nodo (izq,a,der))= in0rden(izq)@[a]@in0rden(der);

fun post0rden (Vacio) = nil
|	post0rden (Nodo (izq,a,der))= post0rden(izq)@post0rden(der)@[a];

(*ejercicio 2*)
type par = real * real;

fun dist ((x,y):par)= x*x+y*y;
fun listdist (l:par list) = map dist l;

fun	S (x:real,y:real) = x + y;
fun sumdist l:par list = foldr S 0.0 (listdist(l));

fun lejos (x:par) = dist(x)>5.0;
fun puntosalejados l:par list = filter lejos l;

(*ejercicio 3*)
type notas = string * int;

fun listar_en_orden_creciente (Vacio) = nil
|	listar_en_orden_creciente (Nodo (izq, est:notas, der)) = in0rden(izq)@[est]@in0rden(der);

fun F((x,y):notas)= (y=10);
fun	buscar_sobresalientes (Nodo (izq,est:notas,der)) = filter F listar_en_orden_creciente(Nodo(izq,est,der));