(*Ej 1*)
(*a*)
fun preOrden(vacio)=nil
|preOrden(Nodo(izq,a,der))=[a]@preOrden(izq)@preOrden(der);
(*b*)
 fun inOrden(vacio)=nil
|inOrden(Nodo(izq,a,der))=inOrden(izq)@[a]@inOrden(der);
(*c*)
 fun postOrden(vacio)=nil
|postOrden(Nodo(izq,a,der))=postOrden(izq)@postOrden(der)@[a];
(*Ej 2*)
(*a*)
fun dist_origen_coordenadas(x:real,y)=Real.Math.sqrt((x*x)+(y*y));(*en la consola la probe con la suma de los cuadrados nada mas*)
fun listdist (l:par list)=map dist_origen_coordenadas l;
(*b*)
 fun suma(a:real,x)=a+x;
 fun sumadist(l:par list)=foldl suma 0.0 listdist(l);
(*c*)
fun d(x:real,y)=if (dist_origen_coordenadas(x,y)>5.0) then true else false;
fun puntosalejados(l:par list)=filter d l ;
(*Ej 3*)
(*a*)
fun listar_en_orden_creciente(vacio)=nil
|listar_en_orden_creciente(Nodo(izq,(x:string,y:int),der))=inOrden(Nodo(izq,(x,y),der));
(*b*)
fun buscadiez(x:string,y:int)=if (y=10) then true else false;
fun buscar_sobresalientes(vacio)=[] 
|buscar_sobresalientes(Nodo(izq,(x:string,y:int),der))=filter buscadiez (listar_en_orden_creciente(Nodo(izq,(x,y),der)));








