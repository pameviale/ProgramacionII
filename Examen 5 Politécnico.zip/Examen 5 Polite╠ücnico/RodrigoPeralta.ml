open List;

(*EJERCICIO 1*)
datatype 'a arbolbin= 
Vacio |
Nodo of 'a arbolbin * 'a * 'a arbolbin;

(*APARTADO a*)
fun preOrden Vacio = nil
| preOrden (Nodo(izq,a,der)) = [a] @ preOrden izq @ preOrden der;

(*APARTADO b*)
fun inOrden Vacio = nil
| inOrden (Nodo(izq,a,der)) = inOrden izq @ [a] @ inOrden der;

(*APARTADO c*)
fun postOrden Vacio = nil
| postOrden (Nodo(izq,a,der)) = postOrden izq @ postOrden der @ [a];

(*EJERCICIO 2*)
type par = real * real;

(*APARTADO a*)
fun DOC (x:real,y:real)=(x*x+y*y);
fun listdist L = map DOC L;

(*APARTADO b*)
fun suma (x:real,y:real) = x+y;
fun sumalista L = foldl suma 0.0 L;
fun sumdist L = sumalista (listdist L);

(*APARTADO c*)
fun may (x,y) = DOC (x,y) > 5.0;
fun puntosalejados L = filter may L;

(*EJERCICIO 3*)

(*APARTADO a*)
fun LENC ar = inOrden ar;

(*APARTADO b*)
fun SS (x,y) = y=10;
fun BS ar = filter SS (LENC ar);

